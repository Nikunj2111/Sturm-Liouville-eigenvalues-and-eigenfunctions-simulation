"""Math visualizer modules."""

